import React from 'react';

function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Bienvenue à Ancienne Maison</h1>
      <p>Site hébergé avec GitHub Pages</p>
    </div>
  );
}

export default App;